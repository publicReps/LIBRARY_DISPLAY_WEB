<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // Allow all origins
header('Access-Control-Allow-Methods: GET, POST, OPTIONS'); // Allow specific methods
header('Access-Control-Allow-Headers: Content-Type'); // Allow specific headers

$response = array();

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['q'])) {

    // Database connection parameters
    $serverName = "DESKTOP-E17B10B\SQLEXPRESS";
    $connectionOptions = array(
        "Database" => "SOUL30",
        "Uid" => "sa",
        "PWD" => "sa@123"
    );
    // Establish the connection
    $conn = sqlsrv_connect($serverName, $connectionOptions);
        
    // Check connection
    if ($conn === false) {
        $response['error'] = "Connection failed: " . print_r(sqlsrv_errors(), true);
        echo json_encode($response);
        exit;
    }

    // Sanitize the input
    $query = $_GET['q'];
    
    // Prepare and execute the SQL statement
    $sql = "SELECT * FROM final";
    $params = array($query);
    $stmt = sqlsrv_query($conn, $sql, $params);
    
    if ($stmt === false) {
        $response['error'] = "Query failed: " . print_r(sqlsrv_errors(), true);
        echo json_encode($response);
        exit;
    }

    // Fetch and display the result
    $data = array();
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $data[] = $row;
    }

    $response['data'] = $data;
    echo json_encode($response);

    // Free statement and close connection
    sqlsrv_free_stmt($stmt);
    sqlsrv_close($conn);
} else {
    $response['error'] = "Invalid request method or missing query parameter.";
    echo json_encode($response);
}
?>