// First script for the first div
const library_images = [
    '1.jpg',
    '2.jpg',
    '3.jpg',
    '1.jpg',
];

const library_demoImages = [
    'nbooks/demo1.jpg',
    'nbooks/demo2.jpg',
];

let library_currentIndex = 0;
const library_imagesToShow = 3;
const library_imageContainer = document.getElementById('s_img');

function library_displayImages() {
    library_imageContainer.innerHTML = ''; // Clear the container
    const endIndex = library_currentIndex + library_imagesToShow;
    const imagesToDisplay = library_images.slice(library_currentIndex, endIndex);

    // Add demo images if necessary to fulfill the limit of 3 images
    while (imagesToDisplay.length < library_imagesToShow) {
        imagesToDisplay.push(library_demoImages[imagesToDisplay.length % library_demoImages.length]);
    }

    imagesToDisplay.forEach(image => {
        const imgElement = document.createElement('img');
        imgElement.src = image;
        imgElement.alt = 'Image';
        library_imageContainer.appendChild(imgElement);
    });

    library_currentIndex += library_imagesToShow;

    if (library_currentIndex >= library_images.length) {
        library_currentIndex = 0; // Reset to the beginning
    }
}

// Initial display
library_displayImages();

// Change images every 5 seconds
setInterval(library_displayImages, 5000);

// Second script for the second div
const images = [
    { id: 1, src: 'nbooks/1.jpg', title: 'Book 1' },
    { id: 2, src: 'nbooks/2.jpg', title: 'Book 2' },
    { id: 3, src: 'nbooks/3.jpg', title: 'Book 3' },
    { id: 4, src: 'nbooks/4.jpg', title: 'Book 4' },
    { id: 5, src: 'nbooks/5.jpg', title: 'Book 5' },
    { id: 6, src: 'nbooks/6.jpg', title: 'Book 6' },
    { id: 7, src: 'nbooks/7.jpg', title: 'Book 7' },
    { id: 8, src: 'nbooks/8.jpg', title: 'Book 8' },
];

const demoImages = [
    { id: 'demo1', src: 'nbooks/demo1.jpg', title: 'Demo Book 1' },
    { id: 'demo2', src: 'nbooks/demo2.jpg', title: 'Demo Book 2' },
];

let currentIndex = 0;
const imagesToShow = 5;
const imageContainer = document.getElementById('fs_img');

function displayImages() {
    imageContainer.innerHTML = ''; // Clear the container
    let endIndex = currentIndex + imagesToShow;
    let imagesToDisplay = images.slice(currentIndex, endIndex);

    // Add demo images if necessary to fulfill the limit of 5 images
    while (imagesToDisplay.length < imagesToShow) {
        imagesToDisplay.push(demoImages[imagesToDisplay.length % demoImages.length]);
    }

    imagesToDisplay.forEach(image => {
        const cardDiv = document.createElement('div');
        cardDiv.className = 'card';

        const imgElement = document.createElement('img');
        imgElement.src = image.src;
        imgElement.alt = image.title;

        const titleElement = document.createElement('h3');
        titleElement.textContent = image.title;

        const idElement = document.createElement('p');
        idElement.textContent = `ID: ${image.id}`;

        cardDiv.appendChild(imgElement);
        cardDiv.appendChild(titleElement);
        cardDiv.appendChild(idElement);

        imageContainer.appendChild(cardDiv);
    });

    currentIndex += imagesToShow;

    if (currentIndex >= images.length) {
        currentIndex = 0; // Reset to the beginning
    }
}

// Initial display
displayImages();

// Change images every 5 seconds
setInterval(displayImages, 5000);