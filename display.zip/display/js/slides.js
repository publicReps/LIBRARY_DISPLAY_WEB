let slideIndex = 0;
showSlides();

function slide_timeset(slides, slideIndex){
    if(slideIndex-1 === 0) {
        slides[slideIndex-1].style.display = "block";  
        setTimeout(showSlides, 10 * 1000);
        // console.log("10");
    } else if (slideIndex-1 === 1) {
        slides[slideIndex-1].style.display = "block";
        fetchMainImages().then(images => displayMainImages(images));
        setTimeout(showSlides, 10 * 1000);
        // console.log("20");
    } else {
        slides[slideIndex-1].style.display = "block";
        fetchLibraryImages().then(images => displayLibraryImages(images));
        setTimeout(showSlides, 10 * 1000);
        // console.log("30");
    }

}


function showSlides() {
    let i;
    let slides = document.getElementsByClassName("mySlides");
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    // slides[slideIndex-1].style.display = "block";  
    // setTimeout(showSlides, 10 * 1000); // Change slide every 2 seconds
    slide_timeset(slides, slideIndex);
}