<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // Allow all origins
header('Access-Control-Allow-Methods: GET, POST, OPTIONS'); // Allow specific methods
header('Access-Control-Allow-Headers: Content-Type'); // Allow specific headers

$response = array();

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['q'])) {

    // Database connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "dashboard";

    // Establish the connection
    $conn = new mysqli($servername, $username, $password, $database);
    
    // Check connection
    if ($conn->connect_error) {
        $response['error'] = "Connection failed: " . $conn->connect_error;
        echo json_encode($response);
        exit;
    }

    // Sanitize the input
    $query = $conn->real_escape_string($_GET['q']);
    
    // Prepare and execute the SQL statement
    $sql = "SELECT header FROM fdashboard WHERE id = $query";
    $result = $conn->query($sql);
    
    if ($result === false) {
        $response['error'] = "Query failed: " . $conn->error;
        echo json_encode($response);
        exit;
    }

    // Fetch and display the result
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $response['data'] = array("header" => $row['header'], "header1" => "how are you");
    } else {
        $response['data'] = "No data found";
    }

    echo json_encode($response);

    // Close connection
    $conn->close();
} else {
    $response['error'] = "Invalid request method or missing query parameter.";
    echo json_encode($response);
}
?>