document.getElementById('openDrawerBtn').addEventListener('click', function() {
    const drawer = document.getElementById('message');
    drawer.style.display = 'block';
    setTimeout(() => {
        drawer.classList.add('show');
    }, 10); // Small delay to ensure the transition works
});

document.getElementById('closeDrawerBtn').addEventListener('click', function() {
    const drawer = document.getElementById('message');
    drawer.classList.remove('show');
    setTimeout(() => {
        drawer.style.display = 'none';
    }, 500); // Match the duration of the transition
});

// notice script
document.getElementById('openDrawerBtn1').addEventListener('click', function() {
    const drawer = document.getElementById('message1');
    drawer.style.display = 'block';
    setTimeout(() => {
        drawer.classList.add('show');
    }, 10); // Small delay to ensure the transition works
});

document.getElementById('closeDrawerBtn1').addEventListener('click', function() {
    const drawer = document.getElementById('message1');
    drawer.classList.remove('show');
    setTimeout(() => {
        drawer.style.display = 'none';
    }, 500); // Match the duration of the transition
});