<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // Allow all origins
header('Access-Control-Allow-Methods: GET, POST, OPTIONS'); // Allow specific methods
header('Access-Control-Allow-Headers: Content-Type'); // Allow specific headers

// function getCurrentDateTime(){
//     return date("Y/m/d H:i:s.000");
// }
date_default_timezone_set('Asia/Kolkata'); // Replace with your desired time zone
$serverName = "DESKTOP-E17B10B\SQLEXPRESS";
$connectionOptions = array(
    "Database" => "SOUL30",
    "Uid" => "sa",
    "PWD" => "sa@123"
);
// Establish the connection
$conn = sqlsrv_connect($serverName, $connectionOptions);

// Check connection
if ($conn === false) {
    $data['error'] = "Connection failed: " . print_r(sqlsrv_errors(), true);
    echo json_encode($data);
    exit;
}

// Prepare and execute the SQL statement
$sql = "WITH AggregatedResults AS (
    SELECT 
        t.mem_id, 
        t.mem_cd, 
        CONVERT(DATE, t.Login_time) AS Login_time, 
        CONVERT(DATE, t.Logout_time) AS Logout_time, 
        t.fullname,
		t.depart,
        COUNT(t.mem_cd) AS mem_cd_count
    FROM 
        t_memlogV AS t
	WHERE t.Login_time BETWEEN '2025-01-16 00:00:00.000' AND '2025-10-16 00:00:00.000'

    GROUP BY
        t.mem_id,
        t.mem_cd,
        CONVERT(DATE, t.Login_time),
        CONVERT(DATE, t.Logout_time),
        t.fullname,
		t.depart
    HAVING
        COUNT(t.mem_cd) > 0
)
SELECT TOP 1 
    ar.mem_id, 
    ar.mem_cd, 
    ar.Login_time, 
    ar.Logout_time, 
    ar.fullname,
	ar.depart,
	p.member_photo
FROM 
    AggregatedResults AS ar
LEFT JOIN mem_photo AS p ON p.mem_cd = ar.mem_cd
ORDER BY
    ar.mem_cd_count DESC";
$stmt = sqlsrv_query($conn, $sql);

if ($stmt === false) {
    $response['error'] = "Query failed: " . print_r(sqlsrv_errors(), true);
    echo json_encode($response);
    exit;
}

// Fetch and display the result
$data = array();
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    // If member_photo is binary data, encode it in base64
    if (isset($row['member_photo']) && $row['member_photo'] !== '') {
        $row['member_photo'] = 'data:image/png;base64,' . base64_encode($row['member_photo']);
    }
    // $data[] = $row;
    $data = array("mem_id" => $row['mem_id'], "mem_cd" => $row['mem_cd'], "Login_time" => $row['Login_time'], "Logout_time" => $row['Logout_time'], "fullname" => $row['fullname'], "member_photo" => $row['member_photo']);
}

// $response['data'] = $data;
// $response = array("data" => $data);
echo json_encode($data);

// Free statement and close connection
sqlsrv_free_stmt($stmt);
sqlsrv_close($conn);
?>