<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // Allow all origins
header('Access-Control-Allow-Methods: GET, POST, OPTIONS'); // Allow specific methods
header('Access-Control-Allow-Headers: Content-Type'); // Allow specific headers

// function getCurrentDateTime(){
//     return date("Y/m/d H:i:s.000");
// }
// http://127.0.0.1/test/circulation/display/test1.php?q=2025-02-16&qs=2025-02-17
date_default_timezone_set('Asia/Kolkata'); // Replace with your desired time zone
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['q'])) {

    $serverName = "DESKTOP-E17B10B\SQLEXPRESS";
    $connectionOptions = array(
        "Database" => "SOUL30",
        "Uid" => "sa",
        "PWD" => "sa@123"
    );
    // Establish the connection
    $conn = sqlsrv_connect($serverName, $connectionOptions);

    // Check connection
    if ($conn === false) {
        $data['error'] = "Connection failed: " . print_r(sqlsrv_errors(), true);
        echo json_encode($data);
        exit;
    }

    $query = $_GET['q'];
    if ($query === '1') {
        // $query = '2025-01-16';
        $starting = '2024-01-16';
        $ending = '2025-09-16';
    } elseif ($query === '2') {
        $starting = '2023-01-16';
        $ending = '2024-09-16';
    } elseif ($query === '3') {
        $starting = '2022-01-16';
        $ending = '2023-09-16';
    } else {
        exit;
    }
    // echo $query;
    // $querys = $_GET['qs'];
    function main($conn, $starting, $ending) {

        // Prepare and execute the SQL statement
        $sql = "WITH AggregatedResults AS (
            SELECT 
                t.mem_id, 
                t.mem_cd, 
                CONVERT(DATE, t.Login_time) AS Login_time, 
                CONVERT(DATE, t.Logout_time) AS Logout_time, 
                t.fullname,
                t.depart,
                COUNT(t.mem_cd) AS mem_cd_count
            FROM 
                t_memlogV AS t
            WHERE t.Login_time BETWEEN ? AND ?

            GROUP BY
                t.mem_id,
                t.mem_cd,
                CONVERT(DATE, t.Login_time),
                CONVERT(DATE, t.Logout_time),
                t.fullname,
                t.depart
            HAVING
                COUNT(t.mem_cd) > 0
        )
        SELECT TOP 1 
            ar.mem_id, 
            ar.mem_cd, 
            ar.Login_time, 
            ar.Logout_time, 
            ar.fullname,
            ar.depart,
            p.member_photo
        FROM 
            AggregatedResults AS ar
        LEFT JOIN mem_photo AS p ON p.mem_cd = ar.mem_cd
        ORDER BY
            ar.mem_cd_count DESC";
        $params = array($starting, $ending);
        $stmt = sqlsrv_query($conn, $sql, $params);

        if ($stmt === false) {
            $response['error'] = "Query failed: " . print_r(sqlsrv_errors(), true);
            echo json_encode($response);
            exit;
        }

        // Fetch and display the result
        $data = array();
        while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            if (isset($row['member_photo']) && $row['member_photo'] !== '') {
                $row['member_photo'] = 'data:image/png;base64,' . base64_encode($row['member_photo']);
            }
            // $data[] = $row;
            $data = array("mem_id" => $row['mem_id'], "mem_cd" => $row['mem_cd'], "Login_time" => $row['Login_time'], "Logout_time" => $row['Logout_time'], "fullname" => $row['fullname'], "member_photo" => $row['member_photo']);
            return $data;
        }
        sqlsrv_free_stmt($stmt);
        return array("mem_id" => 'BSC/2023/09', "mem_cd" => 'BASDFF23201', "Login_time" => '2025-01-01', "Logout_time" => '2025-12-01', "fullname" => 'Firstname Lastnames', 'member_photo' => 'icon/img_avatar.png');

    }
    $y = '2025-02-16';
    $main = main($conn, $starting, $ending);
    // $response['data'] = $data;
    // $response = array("data" => $data);
    // echo json_encode($data);
    echo json_encode($main);
    // Free statement and close connection
    sqlsrv_close($conn);
}
?>