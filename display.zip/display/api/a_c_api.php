<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // Allow all origins
header('Access-Control-Allow-Methods: GET, POST, OPTIONS'); // Allow specific methods
header('Access-Control-Allow-Headers: Content-Type'); // Allow specific headers

// Database connection parameters
$serverName = "DESKTOP-E17B10B\SQLEXPRESS";
$connectionOptions = array(
    "Database" => "SOUL30",
    "Uid" => "sa",
    "PWD" => "sa@123"
);
// Establish the connection
$conn = sqlsrv_connect($serverName, $connectionOptions);

// Check connection
if ($conn === false) {
    $response['error'] = "Connection failed: " . print_r(sqlsrv_errors(), true);
    echo json_encode($data);
    exit;
}

// date_default_timezone_set('Asia/Kolkata'); // Replace with your desired time zone

// Prepare and execute the SQL statement
// $sql = "SELECT * FROM a_display";

function main($conn, $obs) {
    $sql = "SELECT COUNT(t.mem_cd) AS counts FROM t_memlog AS t
    LEFT JOIN m_member AS m ON m.mem_cd = t.mem_cd 
    WHERE m.mem_gender = ?";
    $param = array($obs);
    $stmt = sqlsrv_query($conn, $sql, $param);

    if ($stmt === false) {
        $response['error'] = "Query failed: " . print_r(sqlsrv_errors(), true);
        echo json_encode($data1);
        exit;
    }

    // $data = array();
    // Fetch and display the result
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $data = $row['counts'];
        return $data;
    }
    sqlsrv_free_stmt($stmt);

}

$obs = 'female';
$obs1 = 'male';
$data1 = array("female" => main($conn, $obs), "male" => main($conn, $obs1));


echo json_encode($data1);
// Free statement and close connection
sqlsrv_close($conn);
?>